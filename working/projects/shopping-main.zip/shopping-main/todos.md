unneccesary information from user --- done
-----email phone password ----- done

places order with out cart items ( momo )

Google places suggestion
---google places api

receives in accurate emails as well
---regex or (yup + formik)
