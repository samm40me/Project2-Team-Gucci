export const checkForPassword = (password) => {
  return password === "" ? false : true;
};
