import React from "react";
import HomeScreenComponent from "./home-component";

const HomeScreenContainer = () => {
  return <HomeScreenComponent />;
};

export default HomeScreenContainer;
