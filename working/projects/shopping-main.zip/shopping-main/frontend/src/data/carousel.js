export const carouselData = [
  { img: "/images/burger-2.jpg", name: "Beef Burgers", shortDesc: "" },
  {
    img: "/images/chicken-khebab.jpg",
    name: "Grilled Chicken Khebab",
    shortDesc: "",
  },
  { img: "/images/fruit-3.jpg", name: "Juicy Berry Juice", shortDesc: "" },
];
