export const paymentOptions = [
  { value: "", label: "Select Payment Method" },
  { value: "cashOnDelivery", label: "Cash On Delivery" },
  { value: "mobileMoney", label: "Mobile Money" },
];
