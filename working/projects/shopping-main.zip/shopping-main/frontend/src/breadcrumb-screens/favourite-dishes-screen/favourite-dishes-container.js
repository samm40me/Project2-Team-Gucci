import React from "react";
import FavouritesDishesComponent from "./favourite-dishes-component";

const FavouritesDishesContainer = () => {
  return <FavouritesDishesComponent />;
};

export default FavouritesDishesContainer;
