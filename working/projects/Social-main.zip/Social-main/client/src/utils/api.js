const url = 'https://social-v1-app.herokuapp.com';
// const url = 'http://localhost:5000';
export default url;
