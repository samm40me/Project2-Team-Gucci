<?php

if ( $msgs ) {

    $this->out( $msgs );
}

?>