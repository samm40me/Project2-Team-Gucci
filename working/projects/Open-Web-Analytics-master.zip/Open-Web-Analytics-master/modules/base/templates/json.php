<?php 

    echo $json;

?>