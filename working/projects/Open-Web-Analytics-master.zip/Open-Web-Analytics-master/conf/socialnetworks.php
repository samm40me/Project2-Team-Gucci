<?php 

return [
		    
	['domain' => 'facebook'], 
	['domain' => 'twitter'], 
	['domain' => 'pinterest'], 
	['domain' => 'instagram'], 
	['domain' => 'linkedin'], 
	['domain' => 't.co']
];

?>