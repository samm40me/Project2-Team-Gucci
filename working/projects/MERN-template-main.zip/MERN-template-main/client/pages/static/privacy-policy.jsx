import React from 'react';

const Static = props => {
	return (
		<header>
			<h1 className="text centered">Privacy Policy</h1>
		</header>
	);
};

export default Static;

