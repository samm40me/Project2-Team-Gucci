import SmallCard from "./SmallCard";

export default SmallCard;