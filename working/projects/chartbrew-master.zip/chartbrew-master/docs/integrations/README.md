---

canonicalUrl: https://docs.chartbrew.com/integrations/

meta: 
    - property: og:url
      content: https://docs.chartbrew.com/integrations/

---

# Integrations setup

Most integrations work out-of-the-box when Chartbrew is installed, but some might require special setup. This section contains all the guides to set up these types of integrations.

---

### Contents

[Google Analytics](/integrations/google-analytics)
