import React from "react";
import { Loader } from "semantic-ui-react";

function SuspenseLoader() {
  return (
    <Loader active />
  );
}

export default SuspenseLoader;
