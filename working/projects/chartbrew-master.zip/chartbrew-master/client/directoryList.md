    |-- .eslintrc.json
    |-- package.json
    |-- semantic.json
    |-- config
    |   |-- env.js
    |   |-- paths.js
    |   |-- polyfills.js
    |   |-- webpack.config.dev.js
    |   |-- webpack.config.prod.js
    |   |-- webpackDevServer.config.js
    |   |-- jest
    |       |-- cssTransform.js
    |       |-- fileTransform.js
    |-- public
    |   |-- cb_logo_4.png
    |   |-- favicon.ico
    |   |-- index.html
    |   |-- manifest.json
    |-- scripts
    |   |-- build.js
    |   |-- start.js
    |   |-- test.js
    |-- src
        |-- actions
        |-- assets
        |-- components
        |-- config
        |-- containers
        |-- reducers
        |-- semantic
            |-- dist
            |-- src
            |   |-- site
            |   |   |-- globals
            |   |       |-- reset.overrides
            |   |       |-- reset.variables
            |   |       |-- site.overrides
            |   |       |-- site.variables
