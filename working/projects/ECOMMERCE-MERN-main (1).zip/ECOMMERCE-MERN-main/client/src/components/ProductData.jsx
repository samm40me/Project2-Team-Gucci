export const ProductsData = [
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/71jFEA4IoEL._AC_SL1500_.jpg",
    "name":"MSI",
    "price":"₹ 58,990.00",
    "description":" MSI Modern 15, Intel 10th Gen. i5-10210U",
    },
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/612rSZsXxyL._AC_SL1500_.jpg",
    "name":"ASUS VivoBook",
    "price":"₹ 42,490.00",
    "description":"ASUS VivoBook Ultra 15 (2020) Intel Core i3-1115G4 11th Gen",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/91Oam4MucXL._AC_SL1500_.jpg",
    "name":"ASUS ROG₹",
    "price":" 1,00,990.00 ",
    "description":"ASUS VivoBook Ultra 15 (2020) Intel Core i3-1115G4 11th Gen",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/51DUjTr-kzL._AC_SL1000_.jpg",
    "name":"Acer Aspire 3",
    "price":"₹ 25,990.00",
    "description":"Acer Aspire 3 A315-23 15.6-inch Laptop",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/71y%2BlIHVdAL._AC_SL1500_.jpg",
    "name":"Apple MacBook Pro",
    "price":"₹ 2,24,900",
    "description":"Apple MacBook Pro (16-inch, 16GB RAM, 1TB Storage)",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/31cvSavzEbL._AC_.jpg",
    "name":"SwooK Quicksand",
    "price":"₹ 1,399.00",
    "description":"SwooK Quicksand Plastic Hard Shell Cover for MacBook Pro 13 Case",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/51D4V89WJ2L._AC_SL1000_.jpg",
    "name":"RAEGR Shield",
    "price":"₹ 1,299.00",
    "description":"RAEGR Shield by ESR MacBook Pro 16-Inch Case",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/51DUjTr-kzL._AC_SL1000_.jpg",
    "name":"AVITA PURA",
    "price":"₹ 25,990.00",
    "description":"AVITA PURA NS14A6INU442-MEGYB 14-inch Laptop",
    },
    ,
    {
    "imgSrc":"https://images-na.ssl-images-amazon.com/images/I/718uP1QbQQL._AC_SL1500_.jpg",
    "name":"Lenovo IdeaPad",
    "price":"₹ 58,595.00",
    "description":"Lenovo IdeaPad Slim 5 11th Gen Intel Core i5 14 FHD",
    }
]