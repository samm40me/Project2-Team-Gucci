const backendUrl = 'https://reddish-reddit.herokuapp.com';

export default backendUrl;
