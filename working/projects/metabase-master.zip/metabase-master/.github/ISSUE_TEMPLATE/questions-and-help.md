---
name: Questions and help
about: If you think you need help with something related to Metabase
title: ''
labels: ".Needs Triage, Type:Question"
assignees: ''

---

For help with installation and setup, information on how specific features work, or general questions about Metabase, please use our discussion forum:

https://discourse.metabase.com

The Github issue tracker is intended to collect bug reports and feature requests.
Any issues open for help requests will be closed to keep from clogging up the issue tracker.
