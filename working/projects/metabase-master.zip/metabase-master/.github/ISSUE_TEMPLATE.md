
Please use the issue chooser, when creating a new issue:

https://github.com/metabase/metabase/issues/new/choose
