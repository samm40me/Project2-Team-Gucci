<!-- Do not remove this file since the published HTML in the public doc
(https://www.metabase.com/docs/latest/developers-guide.html)
is often referred to in various issues, discussions, etc -->

Please refer to the detailed [Developer's Guide](developers-guide/start.md).