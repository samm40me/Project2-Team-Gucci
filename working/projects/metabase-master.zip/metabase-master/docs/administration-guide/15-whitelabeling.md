## White labeling Metabase

This page has been moved [here](../enterprise-guide/whitelabeling.md).
