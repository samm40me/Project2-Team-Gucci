## Sandboxing your data

This page has been moved [here](../enterprise-guide/data-sandboxes.md).
