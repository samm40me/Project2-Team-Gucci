## Authenticating with SAML

This page has been moved [here](../enterprise-guide/authenticating-with-saml.md).
