## JWT-based Authentication

This page has been moved [here](../enterprise-guide/authenticating-with-jwt.md).
