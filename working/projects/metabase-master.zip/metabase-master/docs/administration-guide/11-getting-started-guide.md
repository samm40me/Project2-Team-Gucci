## Getting Started Guide

The Getting Started Guide was removed from Metabase in version 0.30. Instead, a great way of helping your teammates find their way around Metabase is by pinning the most important dashboards or questions in each of your collections to make it clear what's most important.
