# Slack

/api/slack endpoints.

  - [GET /api/slack/manifest](#get-apislackmanifest)
  - [PUT /api/slack/settings](#put-apislacksettings)

## `GET /api/slack/manifest`

Returns the YAML manifest file that should be used to bootstrap new Slack apps.

## `PUT /api/slack/settings`

Update Slack related settings. You must be a superuser to do this. Also updates the slack-cache.
  There are 3 cases where we alter the slack channel/user cache:
  1. falsy token           -> clear
  2. invalid token         -> clear
  3. truthy, valid token   -> refresh .

### PARAMS:

*  **`slack-app-token`** value may be nil, or if non-nil, value must be a non-blank string.

*  **`slack-files-channel`** value may be nil, or if non-nil, value must be a non-blank string.

---

[<< Back to API index](../api-documentation.md)