# Login history

  - [GET /api/login-history/current](#get-apilogin-historycurrent)

## `GET /api/login-history/current`

Fetch recent logins for the current user.

---

[<< Back to API index](../api-documentation.md)