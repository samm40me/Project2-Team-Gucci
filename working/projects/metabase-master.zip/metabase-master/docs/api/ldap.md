# Ldap

/api/ldap endpoints.

  - [PUT /api/ldap/settings](#put-apildapsettings)

## `PUT /api/ldap/settings`

Update LDAP related settings. You must be a superuser to do this.

### PARAMS:

*  **`settings`** value must be a map.

---

[<< Back to API index](../api-documentation.md)