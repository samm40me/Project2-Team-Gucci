# Working with Clojure

Check out [Clojure for the Brave and True](https://www.braveclojure.com/clojure-for-the-brave-and-true/). It's free online. 

If you don't feel like reading a whole book, [Mark Volkmann's Clojure tutorial](https://objectcomputing.com/resources/publications/sett/march-2009-clojure-functional-programming-for-the-jvm) is another good starting point. 


