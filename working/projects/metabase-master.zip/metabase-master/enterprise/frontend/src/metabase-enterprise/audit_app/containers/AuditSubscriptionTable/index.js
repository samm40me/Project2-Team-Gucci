export { default } from "./AuditSubscriptionTable";
