export { default } from "./ApplicationPermissionsPage";
