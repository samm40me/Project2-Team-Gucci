import styled from "@emotion/styled";

export const ModalMessage = styled.div`
  &:not(:last-child) {
    margin-bottom: 1rem;
  }
`;
