import React from "react";

const AuditSchemaDetail = () => <div>todo schema</div>;

export default AuditSchemaDetail;
