(ns metabase-enterprise.core
  "Empty namespace. This is here solely so we can try to require it and see whether or not EE code is on the classpath.")
