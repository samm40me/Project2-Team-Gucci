const backendUrl = 'https://stackuflow.herokuapp.com';

export default backendUrl;
