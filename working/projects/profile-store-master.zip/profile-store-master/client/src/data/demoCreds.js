const demoCredentials = "Email: 'test@test.com' & password: 'password'";

export default demoCredentials;
