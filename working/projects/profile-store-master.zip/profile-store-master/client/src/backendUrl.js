const backendUrl = 'https://profile-store.herokuapp.com';

export default backendUrl;
